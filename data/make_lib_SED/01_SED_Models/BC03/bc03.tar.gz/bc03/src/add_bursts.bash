#! /bin/sh

# Script add_bursts.sh
source $bc03/.bc_bash
$bc03/add_bursts
source ./bc03.rm
\rm bc03.rm
