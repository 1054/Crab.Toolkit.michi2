#! /bin/sh

# Script vel_disp.sh
source $bc03/.bc_bash
$bc03/vel_disp
# source ./bc03.rm
\rm bc03.rm
